
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `bitacora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bitacora` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `accion_Bit` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `comentario_Bit` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_Usuario` int(10) unsigned NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bitacora_id_usuario_foreign` (`id_Usuario`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bitacora` WRITE;
/*!40000 ALTER TABLE `bitacora` DISABLE KEYS */;
INSERT INTO `bitacora` VALUES (1,'Registro','Registro de Condominio: Evelyn Yamileth Hernández Gómez',3,NULL,'2018-05-23 03:13:45','2018-05-23 03:13:45'),(2,'Crear','Creacion de Restauracion de Base ',3,NULL,'2018-05-23 04:13:01','2018-05-23 04:13:01'),(3,'Crear','Creacion de Restauracion de Base ',3,NULL,'2018-05-23 04:29:07','2018-05-23 04:29:07'),(4,'Crear','Creacion de Restauracion de Base ',3,NULL,'2018-05-23 04:47:35','2018-05-23 04:47:35');
/*!40000 ALTER TABLE `bitacora` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `caja_chicas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `caja_chicas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `estado` tinyint(1) NOT NULL,
  `cantidad` double(8,2) NOT NULL,
  `concepto` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_Fecha` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `caja_chicas_id_fecha_foreign` (`id_Fecha`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `caja_chicas` WRITE;
/*!40000 ALTER TABLE `caja_chicas` DISABLE KEYS */;
/*!40000 ALTER TABLE `caja_chicas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `condominios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `condominios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `NLocal` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_Empresa` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `condominios_id_empresa_foreign` (`id_Empresa`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `condominios` WRITE;
/*!40000 ALTER TABLE `condominios` DISABLE KEYS */;
INSERT INTO `condominios` VALUES (1,'edr','A-001',1,'2018-05-23 03:10:13','2018-05-23 03:10:13',NULL),(2,'edr','A-001',2,'2018-05-23 03:13:44','2018-05-23 03:13:44',NULL);
/*!40000 ALTER TABLE `condominios` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cuenta_por_cobrars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cuenta_por_cobrars` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mes` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ano` int(11) NOT NULL,
  `concepto` text COLLATE utf8_unicode_ci NOT NULL,
  `id_Fecha` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cuenta_por_cobrars_id_fecha_foreign` (`id_Fecha`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cuenta_por_cobrars` WRITE;
/*!40000 ALTER TABLE `cuenta_por_cobrars` DISABLE KEYS */;
/*!40000 ALTER TABLE `cuenta_por_cobrars` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `empresas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empresas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `correo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `telefonoFijo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefonoMovil` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `empresas` WRITE;
/*!40000 ALTER TABLE `empresas` DISABLE KEYS */;
INSERT INTO `empresas` VALUES (1,'Evelyn Yamileth Hernández Gómez','evelyn@gmail.com','+(222) 2222-2222','+(888) 8888-8888','2018-05-23 03:10:13','2018-05-23 03:10:13',NULL),(2,'Evelyn Yamileth Hernández Gómez','evelyn@gmail.com','+(222) 2222-2222','+(888) 8888-8888','2018-05-23 03:13:44','2018-05-23 03:13:44',NULL);
/*!40000 ALTER TABLE `empresas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `estados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estados` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mes` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ano` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `concepto` enum('Administrativo','Parqueo','Otros') COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_Condominio` int(10) unsigned NOT NULL,
  `id_Fecha` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `estados_id_condominio_foreign` (`id_Condominio`),
  KEY `estados_id_fecha_foreign` (`id_Fecha`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `estados` WRITE;
/*!40000 ALTER TABLE `estados` DISABLE KEYS */;
INSERT INTO `estados` VALUES (1,'Enero',2018,0,'Administrativo',NULL,1,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(2,'Febrero',2018,0,'Administrativo',NULL,1,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(3,'Marzo',2018,0,'Administrativo',NULL,1,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(4,'Abril',2018,0,'Administrativo',NULL,1,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(5,'Mayo',2018,0,'Administrativo',NULL,1,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(6,'Junio',2018,0,'Administrativo',NULL,1,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(7,'Enero',2018,0,'Parqueo',NULL,1,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(8,'Febrero',2018,0,'Parqueo',NULL,1,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(9,'Marzo',2018,0,'Parqueo',NULL,1,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(10,'Abril',2018,0,'Parqueo',NULL,1,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(11,'Mayo',2018,0,'Parqueo',NULL,1,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(12,'Junio',2018,0,'Parqueo',NULL,1,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(13,'Enero',2018,0,'Administrativo',NULL,2,2,'2018-05-23 03:13:45','2018-05-23 03:13:45'),(14,'Febrero',2018,0,'Administrativo',NULL,2,2,'2018-05-23 03:13:45','2018-05-23 03:13:45'),(15,'Marzo',2018,0,'Administrativo',NULL,2,2,'2018-05-23 03:13:45','2018-05-23 03:13:45'),(16,'Abril',2018,0,'Administrativo',NULL,2,2,'2018-05-23 03:13:45','2018-05-23 03:13:45'),(17,'Mayo',2018,0,'Administrativo',NULL,2,2,'2018-05-23 03:13:45','2018-05-23 03:13:45'),(18,'Junio',2018,0,'Administrativo',NULL,2,2,'2018-05-23 03:13:45','2018-05-23 03:13:45'),(19,'Enero',2018,0,'Parqueo',NULL,2,2,'2018-05-23 03:13:45','2018-05-23 03:13:45'),(20,'Febrero',2018,0,'Parqueo',NULL,2,2,'2018-05-23 03:13:45','2018-05-23 03:13:45'),(21,'Marzo',2018,0,'Parqueo',NULL,2,2,'2018-05-23 03:13:45','2018-05-23 03:13:45'),(22,'Abril',2018,0,'Parqueo',NULL,2,2,'2018-05-23 03:13:45','2018-05-23 03:13:45'),(23,'Mayo',2018,0,'Parqueo',NULL,2,2,'2018-05-23 03:13:45','2018-05-23 03:13:45'),(24,'Junio',2018,0,'Parqueo',NULL,2,2,'2018-05-23 03:13:45','2018-05-23 03:13:45');
/*!40000 ALTER TABLE `estados` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `factura_anuladas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factura_anuladas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_Factura` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `factura_anuladas_id_factura_foreign` (`id_Factura`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `factura_anuladas` WRITE;
/*!40000 ALTER TABLE `factura_anuladas` DISABLE KEYS */;
/*!40000 ALTER TABLE `factura_anuladas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `facturacions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `facturacions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NFactura` text COLLATE utf8_unicode_ci NOT NULL,
  `concepto` enum('Administrativo','Parqueo','Otros') COLLATE utf8_unicode_ci NOT NULL,
  `cantidad` double(8,2) DEFAULT NULL,
  `emision` enum('No Emitido','Emitido','Anulado','Anulado He Imprimir') COLLATE utf8_unicode_ci NOT NULL,
  `permiso` text COLLATE utf8_unicode_ci,
  `mes` text COLLATE utf8_unicode_ci NOT NULL,
  `ano` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `id_Fecha` int(10) unsigned NOT NULL,
  `id_Estado` int(10) unsigned NOT NULL,
  `id_Condominio` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `facturacions_id_fecha_foreign` (`id_Fecha`),
  KEY `facturacions_id_estado_foreign` (`id_Estado`),
  KEY `facturacions_id_condominio_foreign` (`id_Condominio`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `facturacions` WRITE;
/*!40000 ALTER TABLE `facturacions` DISABLE KEYS */;
INSERT INTO `facturacions` VALUES (1,'','Administrativo',50.00,'Emitido',NULL,'Enero',2018,0,1,1,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(2,'','Administrativo',50.00,'Emitido',NULL,'Febrero',2018,0,1,2,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(3,'','Administrativo',50.00,'Emitido',NULL,'Marzo',2018,0,1,3,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(4,'','Administrativo',50.00,'Emitido',NULL,'Abril',2018,0,1,4,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(5,'','Administrativo',50.00,'Emitido',NULL,'Mayo',2018,0,1,5,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(6,'','Administrativo',50.00,'No Emitido',NULL,'Junio',2018,0,1,6,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(7,'','Parqueo',15.00,'Emitido',NULL,'Enero',2018,0,1,7,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(8,'','Parqueo',15.00,'Emitido',NULL,'Febrero',2018,0,1,8,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(9,'','Parqueo',15.00,'Emitido',NULL,'Marzo',2018,0,1,9,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(10,'','Parqueo',15.00,'Emitido',NULL,'Abril',2018,0,1,10,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(11,'','Parqueo',15.00,'Emitido',NULL,'Mayo',2018,0,1,11,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(12,'','Parqueo',15.00,'No Emitido',NULL,'Junio',2018,0,1,12,1,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(13,'','Administrativo',50.00,'Emitido',NULL,'Enero',2018,0,2,13,2,'2018-05-23 03:13:45','2018-05-23 03:13:45'),(14,'','Administrativo',50.00,'Emitido',NULL,'Febrero',2018,0,2,14,2,'2018-05-23 03:13:45','2018-05-23 03:13:45'),(15,'','Administrativo',50.00,'Emitido',NULL,'Marzo',2018,0,2,15,2,'2018-05-23 03:13:45','2018-05-23 03:13:45'),(16,'','Administrativo',50.00,'Emitido',NULL,'Abril',2018,0,2,16,2,'2018-05-23 03:13:45','2018-05-23 03:13:45'),(17,'','Administrativo',50.00,'Emitido',NULL,'Mayo',2018,0,2,17,2,'2018-05-23 03:13:45','2018-05-23 03:13:45'),(18,'','Administrativo',50.00,'No Emitido',NULL,'Junio',2018,0,2,18,2,'2018-05-23 03:13:45','2018-05-23 03:13:45'),(19,'','Parqueo',15.00,'Emitido',NULL,'Enero',2018,0,2,19,2,'2018-05-23 03:13:45','2018-05-23 03:13:45'),(20,'','Parqueo',15.00,'Emitido',NULL,'Febrero',2018,0,2,20,2,'2018-05-23 03:13:45','2018-05-23 03:13:45'),(21,'','Parqueo',15.00,'Emitido',NULL,'Marzo',2018,0,2,21,2,'2018-05-23 03:13:45','2018-05-23 03:13:45'),(22,'','Parqueo',15.00,'Emitido',NULL,'Abril',2018,0,2,22,2,'2018-05-23 03:13:45','2018-05-23 03:13:45'),(23,'','Parqueo',15.00,'Emitido',NULL,'Mayo',2018,0,2,23,2,'2018-05-23 03:13:45','2018-05-23 03:13:45'),(24,'','Parqueo',15.00,'No Emitido',NULL,'Junio',2018,0,2,24,2,'2018-05-23 03:13:45','2018-05-23 03:13:45');
/*!40000 ALTER TABLE `facturacions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fechas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fechas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dia` int(11) NOT NULL,
  `mes` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ano` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fechas` WRITE;
/*!40000 ALTER TABLE `fechas` DISABLE KEYS */;
INSERT INTO `fechas` VALUES (1,22,'05',2018,'2018-05-23 03:10:13','2018-05-23 03:10:13'),(2,22,'05',2018,'2018-05-23 03:13:44','2018-05-23 03:13:44');
/*!40000 ALTER TABLE `fechas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `ingreso_diarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingreso_diarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `concepto` enum('Administrativo','Parqueo','Otros') COLLATE utf8_unicode_ci NOT NULL,
  `formaPago` enum('Efectivo','Cheque') COLLATE utf8_unicode_ci NOT NULL,
  `NCheque` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NBanco` text COLLATE utf8_unicode_ci,
  `cantidad` double(8,2) NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_Fecha` int(10) unsigned NOT NULL,
  `id_Condominio` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ingreso_diarios_id_fecha_foreign` (`id_Fecha`),
  KEY `ingreso_diarios_id_condominio_foreign` (`id_Condominio`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `ingreso_diarios` WRITE;
/*!40000 ALTER TABLE `ingreso_diarios` DISABLE KEYS */;
/*!40000 ALTER TABLE `ingreso_diarios` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=542 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (530,'2014_10_12_000000_create_users_table',1),(531,'2014_10_12_100000_create_password_resets_table',1),(532,'2018_04_05_204255_create_empresas_table',1),(533,'2018_04_05_204348_create_fechas_table',1),(534,'2018_04_05_204441_create_condominios_table',1),(535,'2018_04_05_204537_create_estados_table',1),(536,'2018_04_05_204707_create_facturacions_table',1),(537,'2018_04_05_204802_create_factura_anuladas_table',1),(538,'2018_04_05_204903_create_ingreso_diarios_table',1),(539,'2018_04_05_205003_create_cuenta_por_cobrars_table',1),(540,'2018_04_05_205055_create_caja_chicas_table',1),(541,'2018_05_22_200751_Bitacora',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cargo` enum('Financiero','Administracion','Programador') COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Financiera Nombre','financiero@gmail.com','$2y$10$5f9UmVi357pRA73raN.B.OI4ksfGpp2xIiZi3sXooC7VH0LwrZmxm','Financiero',NULL,NULL,NULL),(2,'Administracion Nombre','administrador@gmail.com','$2y$10$OkgEouKmwpezgdTsoWoYy.emADMkrGxFZNtM59BVrNlYHozZ2vYPy','Administracion',NULL,NULL,NULL),(3,'mTTWGroQmm','programador@gmail.com','$2y$10$/0Hb2Y.AoUqm4FcQunG1zuBT33DgBD6r3bBXOmoNTPUZhtWOzOZfa','Programador',NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

